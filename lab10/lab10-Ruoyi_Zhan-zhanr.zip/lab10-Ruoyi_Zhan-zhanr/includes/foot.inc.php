
    </div>
    <div id="footer">
      Introduction to Information Technology and Web Science, Rensselaer Polytechnic Institute
    </div>
  </body>
</html>

