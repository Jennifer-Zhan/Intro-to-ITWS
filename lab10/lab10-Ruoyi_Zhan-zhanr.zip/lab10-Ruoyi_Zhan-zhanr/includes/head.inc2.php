 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
    <script type="text/javascript" src="resources/jquery-1.4.3.min.js"></script>
    <script type="text/javascript" src="resources/iit2.js"></script>   
    <link href="resources/iit2.css" rel="stylesheet" type="text/css"/>
  </head>
  <body>
    <div id="header">
