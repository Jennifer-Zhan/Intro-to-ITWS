In lab5, I learned the basic use of Javascript, HTML, and CSS. I learned how to create a form and edit a form. 

My working URL: https://afsws.rpi.edu/AFS/home/43/zhanr/public_html/iit/lab5
